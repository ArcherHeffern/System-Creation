#include <stdlib.h>
#include <stdio.h>

int main(int argc, char **argv){

  int i1 = 0;
  int i2 = 1;
  int *i3 = malloc(sizeof(int));
  int *i4 = malloc(sizeof(int));

  // %p means print pointer
  // & in this context acts as "address of"
  printf("%p\n%p\n%p\n%p\n",&i1, &i2, &i3, &i4);

  return 0;

}
