#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define BUFLEN 255

int main(int argc, char **argv){

  char *s1 = "hello world";
  char s2[] = "foo bar baz";
  char buf[BUFLEN];

  memset(buf, 0, BUFLEN);

  // function void *memcpy(void *dest, const void *src, size_t n)
  // copies n characters from memory area src to memory area dest.

  memcpy(buf, s2, 3);
  memcpy(buf + 3, s1 + 6, 5);

  printf("%s\n", buf);

  return 0;

}
