#include <stdlib.h>
#include <stdio.h>

int main(int argc, char **argv){

  printf("Hello, world!\n");  // print to the console

  int nums[10];

  for (int i = 0; i < 10; i++){

    printf("[%d]= %d\n",i,nums[i]);

  }

  return 0;                     // 0 means success;

}
