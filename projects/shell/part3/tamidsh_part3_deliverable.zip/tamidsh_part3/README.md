# Tamidsh Part 3
A simple shell with features such as unix style piping, logging, and configuration. 
Man pages are provided with this program.

## Instructions for Compiling and Running the Program
Compile using `make tamidsh` 
Type `./tamidsh` to run the program.

## Configuration
A sample tamidsh_rc is provided. Move it to $HOME or /etc/tamidsh/

## Logs
Logs are written to $HOME/.tamidsh.log

## Known Bugs
One bug is that the input and arguments variables have fixed sizes which means that inputting a long command that exceeds the input size or having many arguments such that it exceeds the argument size will lead to errors.
